#ifndef APPLY_JOB_H
#define APPLY_JOB_H

void analyze(int* pointer, int& reference);

#endif