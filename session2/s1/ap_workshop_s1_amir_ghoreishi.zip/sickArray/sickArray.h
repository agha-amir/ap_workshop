void newArray(int**& arr, int& n);
void squareArray(int**& arr);
void printArray(int**& arr);
void freeArray(int**& arr);